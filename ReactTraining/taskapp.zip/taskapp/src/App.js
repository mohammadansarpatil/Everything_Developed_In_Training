import logo from './logo.svg';
import './App.css';
import DisplayData from './components/DisplayData'
import UserInput from './components/UserInput';

function App() {
  return (
    <UserInput/>


  );
}

export default App;
